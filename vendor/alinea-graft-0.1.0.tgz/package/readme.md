# graft

A git-compatible content store that commits locally and replicates to any git
host. It is the storage and sync engine being built for alinea 3.0.

Editors save to a repository alinea owns. A replicator pushes those commits to
GitHub, GitLab, Gitea or any git server, and a deterministic three-way merge
combines them with developer pushes, so nobody has to resolve conflicts.

See [docs/design.md](docs/design.md) for the decisions and the roadmap.

## Install

```sh
npm install @alinea/graft
```

It runs on Node 24 or later, Bun and Deno. Everything but `@alinea/graft/fs`
uses only web APIs, so it runs in workers and browsers too. The SQL stores need
[rado](https://github.com/benmerckx/rado), which you install next to it.

## Merging

Describe what content looks like, then merge two versions against their base.
Graft assumes no field names: the shape says where identities and order live.

```ts
import {merge, shape as s} from '@alinea/graft'

const page = s.record({
  title: s.atomic(),
  tags: s.set(),
  blocks: s.list(
    s.union('_type', {
      Text: s.record({body: s.atomic()}),
      Image: s.record({src: s.atomic()})
    }),
    {identity: s.byKey('_id'), order: s.byFractionalKey('_index')}
  )
})

const result = merge(page, base, ours, theirs, {prefer: 'ours'})
```

The merge is total: it accepts any JSON and always returns a result.

## Saving

A repository is an object store and a ref store. Saves made from an older
commit are merged onto the newer one instead of failing.

```ts
import {MemoryObjectStore, MemoryRefStore, save} from '@alinea/graft'

const repo = {objects: new MemoryObjectStore(), refs: new MemoryRefStore()}
const contents = new TextEncoder().encode('{"title": "Home"}')
const person = {
  name: 'Ada',
  email: 'ada@example.com',
  timestamp: Math.floor(Date.now() / 1000),
  timezone: '+0000'
}
await save(
  repo,
  'refs/heads/main',
  {
    base: undefined,
    changes: [{op: 'put', path: 'pages/home.json', contents}],
    author: person,
    committer: person,
    message: 'Add home'
  },
  {prefer: 'ours'}
)
```

`gitServer({repo})` serves it over smart HTTP as a `fetch` handler, so
`git clone` works against it.

## SQL

`@alinea/graft/sql` keeps objects and refs in SQL through rado, on SQLite
(including D1 and Durable Objects), Postgres and MySQL. Tables are created on
first use.

```ts
import {DatabaseSync} from 'node:sqlite'
import {sqlRepository} from '@alinea/graft/sql'
import {connect} from 'rado/driver/node-sqlite'

const db = connect(new DatabaseSync('content.db'))
const repo = sqlRepository(db)
```

`@alinea/graft/sql-session` keeps the logs of live editing sessions in the
same database.

```ts
import {SqlSessionLog} from '@alinea/graft/sql-session'

const log = new SqlSessionLog(db)
```

## A local .git

`@alinea/graft/fs` reads the repository at or above a path as git stores it,
on Node, Bun and Deno. It changes nothing unless asked to write.

```ts
import {gitRepository} from '@alinea/graft/fs'

const repo = gitRepository('.')
const head = await repo.refs.get('refs/heads/main')
repo.close()
```

## Development

```sh
bun install
bun test
bun typecheck
bun lint
bun format
bun run check:pack
```

`check:pack` packs the package, installs the tarball into a scratch project
and runs it there on Node, Bun and Deno.

Library code lives in `src/`, tests in `test/`, and generators shared by tests
in `test/support/`.
